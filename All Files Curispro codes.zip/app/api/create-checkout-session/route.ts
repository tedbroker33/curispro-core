/**
 * POST /api/create-checkout-session
 * Body: { priceId: string, quantity?: number, successUrl?: string, cancelUrl?: string }
 * Creates a Stripe Checkout Session (server-side).
 */
import { NextResponse } from 'next/server'
import Stripe from 'stripe'

const stripeSecret = process.env.STRIPE_SECRET_KEY
if (!stripeSecret) {
  console.warn('STRIPE_SECRET_KEY is not set. Checkout sessions will fail in server.');
}

const stripe = stripeSecret ? new Stripe(stripeSecret, { apiVersion: '2022-11-15' }) : null

export async function POST(req: Request) {
  try {
    if (!stripe) return NextResponse.json({ error: 'Stripe not configured' }, { status: 500 })
    const body = await req.json()
    const { priceId, quantity = 1, successUrl = '/', cancelUrl = '/' } = body

    if (!priceId) {
      return NextResponse.json({ error: 'Missing priceId' }, { status: 400 })
    }

    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      line_items: [{ price: priceId, quantity }],
      success_url: successUrl,
      cancel_url: cancelUrl,
    })

    return NextResponse.json({ url: session.url })
  } catch (err: any) {
    console.error('create-checkout-session error:', err)
    return NextResponse.json({ error: err.message || 'Internal error' }, { status: 500 })
  }
}