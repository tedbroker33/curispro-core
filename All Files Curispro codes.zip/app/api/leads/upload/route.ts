/**
 * POST /api/leads/upload
 * Accepts JSON: { leads: [{ name, email, company, phone, metadata? }, ...] }
 * Inserts leads using the server-side supabaseAdmin client.
 */
import { NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabaseAdmin'

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const leads = body?.leads
    if (!Array.isArray(leads) || leads.length === 0) {
      return NextResponse.json({ error: 'Invalid payload: provide leads array' }, { status: 400 })
    }

    // Basic validation & sanitize
    const sanitized = leads.map((l: any) => ({
      name: String(l.name || null),
      email: l.email ? String(l.email).toLowerCase() : null,
      company: l.company ? String(l.company) : null,
      phone: l.phone ? String(l.phone) : null,
      metadata: l.metadata || null,
    }))

    const { data, error } = await supabaseAdmin.from('leads').insert(sanitized).select('id, email, created_at')

    if (error) {
      console.error('Supabase insert error', error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ inserted: data?.length ?? 0, rows: data })
  } catch (err: any) {
    console.error('leads upload error', err)
    return NextResponse.json({ error: err.message || 'Internal error' }, { status: 500 })
  }
}