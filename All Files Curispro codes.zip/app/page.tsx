import OnboardingWizard from '@/components/OnboardingWizard'
import MarketCompare from '@/components/MarketCompare'
import CheckoutDemo from '@/components/CheckoutDemo'

// Replace this placeholder with your real Stripe Price ID from the Stripe Dashboard
const DEMO_PRICE_ID = process.env.NEXT_PUBLIC_DEMO_PRICE_ID || 'price_123_replace_me'

export default function Page() {
  return (
    <div className="container mx-auto py-10">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <MarketCompare />

          {/* Demo Checkout placed below the chart */}
          <div>
            <CheckoutDemo priceId={DEMO_PRICE_ID} />
          </div>
        </div>

        <aside>
          <OnboardingWizard />
        </aside>
      </div>
    </div>
  )
}