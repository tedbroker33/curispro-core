export default function SuccessPage() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="max-w-xl bg-white p-8 rounded-lg shadow">
        <h1 className="text-2xl font-bold mb-2">Payment complete</h1>
        <p className="text-slate-600">Thank you — your subscription is active. Check your email for a receipt.</p>
      </div>
    </div>
  )
}