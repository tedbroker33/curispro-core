'use client'
import React, { useState } from 'react'

type Props = {
  // Stripe Price ID for the product/subscription you want to sell.
  // Example: "price_1N..." — replace with your real price id from the Stripe Dashboard.
  priceId: string
  // optional override for success/cancel urls
  successUrl?: string
  cancelUrl?: string
}

export default function CheckoutDemo({ priceId, successUrl, cancelUrl }: Props) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const createCheckout = async () => {
    setError(null)
    if (!priceId) {
      setError('Missing priceId. Provide a valid Stripe Price ID.')
      return
    }
    setLoading(true)
    try {
      const resp = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          priceId,
          successUrl: successUrl ?? `${window.location.origin}/success`,
          cancelUrl: cancelUrl ?? `${window.location.origin}/`,
        }),
      })

      const data = await resp.json()
      if (!resp.ok) {
        setError(data?.error || 'Failed to create checkout session')
        setLoading(false)
        return
      }

      const checkoutUrl = data?.url
      if (!checkoutUrl) {
        setError('No checkout URL returned from server')
        setLoading(false)
        return
      }

      // Redirect to Stripe Checkout
      window.location.href = checkoutUrl
    } catch (err: any) {
      console.error('checkout error', err)
      setError(err?.message || 'Unexpected error')
      setLoading(false)
    }
  }

  return (
    <div className="p-4 bg-white rounded-lg border border-slate-200 shadow-sm max-w-md">
      <h4 className="font-semibold mb-2">Demo Checkout</h4>
      <p className="text-sm text-slate-600 mb-4">
        This button creates a Stripe Checkout session server-side and redirects to Stripe Checkout.
      </p>

      {error && <div className="text-sm text-red-600 mb-3">{error}</div>}

      <button
        onClick={createCheckout}
        disabled={loading}
        className="w-full inline-flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-md disabled:opacity-60"
      >
        {loading ? 'Creating Checkout...' : 'Buy / Subscribe — Demo'}
      </button>

      <div className="mt-3 text-xs text-slate-500">
        Note: Replace the demo priceId with your real Stripe Price ID in the component props.
      </div>
    </div>
  )
}