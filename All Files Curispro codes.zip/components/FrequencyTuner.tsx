import React from 'react'

/**
 * Server-side FrequencyScript that conditionally injects a hidden "GG33" script.
 * IMPORTANT:
 * - If you want this value available to client code, set NEXT_PUBLIC_ENABLE_FREQUENCY_MODE
 * - Do NOT expose any secret keys here
 */

const enabled = process.env.NEXT_PUBLIC_ENABLE_FREQUENCY_MODE === 'true'

export function FrequencyScript() {
  if (!enabled) return null

  // A minimal, safe inline script example. Replace with your actual logic.
  const script = `
    // GG33 Frequency Script (minimal placeholder)
    try {
      window.__GG33 = { enabled: true, loadedAt: Date.now() }
      console.log('GG33 Frequency Mode: enabled')
      // Add any harmless client-only features here
    } catch(e) {
      console.warn('GG33 script failed', e)
    }
  `

  return (
    // Server component can render a script tag directly
    // It is intentionally inline — keep it small and safe.
    <script
      dangerouslySetInnerHTML={{
        __html: script,
      }}
      data-gg33="frequency-script"
    />
  )
}

export default FrequencyScript