'use client'
import React from 'react'
import {
  LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, CartesianGrid
} from 'recharts'

const sampleData = [
  { month: 'Jan', Bronze: 1200, Silver: 2100, Gold: 3200 },
  { month: 'Feb', Bronze: 1500, Silver: 2300, Gold: 3500 },
  { month: 'Mar', Bronze: 1700, Silver: 2500, Gold: 3800 },
  { month: 'Apr', Bronze: 1900, Silver: 2700, Gold: 4100 },
  { month: 'May', Bronze: 2200, Silver: 3000, Gold: 4400 },
  { month: 'Jun', Bronze: 2400, Silver: 3200, Gold: 4700 }
]

export default function MarketCompare() {
  return (
    <div className="p-6 bg-white rounded-xl shadow-sm border border-slate-200">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">Market Compare</h3>
        <p className="text-sm text-slate-500">Realtime group quoting snapshot</p>
      </div>

      <div style={{ width: '100%', height: 320 }}>
        <ResponsiveContainer>
          <LineChart data={sampleData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
            <CartesianGrid stroke="#f3f4f6" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="Bronze" stroke="#a3e635" strokeWidth={2} />
            <Line type="monotone" dataKey="Silver" stroke="#60a5fa" strokeWidth={2} />
            <Line type="monotone" dataKey="Gold" stroke="#7c3aed" strokeWidth={2} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-4 text-sm text-slate-600">
        This view is a placeholder using mock data. Swap in real plan comparison data from your quoting engine or Supabase queries.
      </div>
    </div>
  )
}