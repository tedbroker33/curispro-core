/**
 * lib/stripe.ts
 * - Server-side Stripe client. Use only in API routes or server components that run on the server.
 * - Never expose STRIPE_SECRET_KEY to the browser.
 */
import Stripe from 'stripe'

const stripeSecret = process.env.STRIPE_SECRET_KEY
if (!stripeSecret) {
  // In local dev you might not have this set; throw in server envs to catch misconfigurations.
  // Do not throw in code that will run in the browser.
  // If you're using this from a serverless function, let the runtime error if missing.
  // throw new Error('STRIPE_SECRET_KEY is not set in environment')
}

export const stripe = stripeSecret ? new Stripe(stripeSecret, { apiVersion: '2022-11-15' }) : null