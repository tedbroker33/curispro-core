/**
 * lib/supabase.ts
 * - For client usage: uses NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY
 * - For server-only work, use a SERVICE_ROLE_KEY stored as SUPABASE_SERVICE_ROLE in server env (DO NOT expose)
 */

import { createClient as createSupabaseClient } from '@supabase/supabase-js'

const url = process.env.NEXT_PUBLIC_SUPABASE_URL || ''
const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''

export const supabase = createSupabaseClient(url, anonKey, {
  auth: { persistSession: false },
})

// NOTE:
// - If you need admin/server actions (RLS bypass), create a separate server-only client with the service role key
//   and only use it from API routes or server functions:
//   const serverSupabase = createSupabaseClient(url, process.env.SUPABASE_SERVICE_ROLE)