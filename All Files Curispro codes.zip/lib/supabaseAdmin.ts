/**
 * Server-side Supabase admin client.
 * Use only in server-side code (API routes, server components).
 * Requires SUPABASE_SERVICE_ROLE environment variable (service role key).
 * Do NOT expose SUPABASE_SERVICE_ROLE to the browser or commit it to source.
 */
import { createClient } from '@supabase/supabase-js'

const url = process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.SUPABASE_URL
const serviceRole = process.env.SUPABASE_SERVICE_ROLE

if (!url || !serviceRole) {
  throw new Error('SUPABASE_SERVICE_ROLE and SUPABASE_URL/NEXT_PUBLIC_SUPABASE_URL must be set for server admin operations')
}

export const supabaseAdmin = createClient(url, serviceRole, {
  auth: { persistSession: false },
})