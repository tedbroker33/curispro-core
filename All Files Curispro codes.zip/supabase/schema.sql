-- Supabase schema for leads table
-- Run this in your Supabase SQL editor or via psql against your DB.
-- Note: If you enable RLS, create policies so only service role can insert/modify as needed.

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text,
  email text,
  company text,
  phone text,
  metadata jsonb,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_leads_email ON leads (lower(email));

-- Example: disable RLS (default). If you enable RLS, create a policy that allows server inserts only via the service role:
-- ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
-- CREATE POLICY service_role_insert ON leads
--   FOR INSERT
--   USING (auth.role() = 'service_role'); -- Note: auth.role() is not real SQL; use check on jwt claims or use service role with no policies.
--
-- Best practice:
-- - Use SUPABASE_SERVICE_ROLE only from server-side code (API routes).
-- - Use anon key in client for readonly or RLS-limited operations.